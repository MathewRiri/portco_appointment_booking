<!-- Booking form (HTML) -->
<div class="formbold-main-wrapper">
  <div class="formbold-form-wrapper">
    <form id="appointmentForm" novalidate>
      <div class="formbold-mb-5">
        <label for="name" class="formbold-form-label">Full Name</label>
        <input type="text" name="name" id="name" placeholder="Full Name" class="formbold-form-input" required />
      </div>

      <div class="formbold-mb-5">
        <label for="phone" class="formbold-form-label">Phone Number</label>
        <input type="tel" name="phone" id="phone" placeholder="Enter your phone number" class="formbold-form-input" required />
      </div>

      <div class="formbold-mb-5">
        <label for="email" class="formbold-form-label">Email Address</label>
        <input type="email" name="email" id="email" placeholder="Enter your email" class="formbold-form-input" required />
      </div>

      <div class="formbold-mb-5">
        <label for="service" class="formbold-form-label">Preferred Service / Department</label>
        <select class="formbold-form-input" name="service" id="service" required>
          <option value="">-- Select Service --</option>
          <option>Consultations (General, Paediatric, Gynaecology)</option>
          <option>Laboratory</option>
          <option>Pharmacy</option>
          <option>Ultrasound</option>
          <option>Family Planning</option>
          <option>Maternity Care (Antenatal & Postnatal)</option>
          <option>Minor Surgery</option>
        </select>
      </div>

      <div class="flex flex-wrap formbold--mx-3">
        <div class="w-full sm:w-half formbold-px-3">
          <div class="formbold-mb-5 w-full">
            <label for="date" class="formbold-form-label">Preferred Date</label>
            <input type="date" name="date" id="date" class="formbold-form-input" required />
          </div>
        </div>

        <div class="w-full sm:w-half formbold-px-3">
          <div class="formbold-mb-5">
            <label for="time" class="formbold-form-label">Preferred Time</label>
            <input type="time" name="time" id="time" class="formbold-form-input" required />
          </div>
        </div>
      </div>

      <div class="formbold-mb-5">
        <label for="notes" class="formbold-form-label">Reason / Additional Notes (optional)</label>
        <textarea id="notes" name="notes" placeholder="Any notes or special requests" class="formbold-form-input" rows="3"></textarea>
      </div>

      <div>
        <button type="submit" class="formbold-btn">Book Appointment</button>
      </div>

      <p id="statusMessage" style="margin-top:.75rem; color: #1a73e8; display:none;"></p>
    </form>
  </div>
</div>

<!-- JavaScript: collect form data, validate, open WhatsApp -->
					     <!-- <form id="#" class="appoinment-form" method="post" action="#">
                    <div class="row">
                         <div class="col-lg-6">
                            <div class="form-group">
                                <select class="form-control" id="exampleFormControlSelect1">
                                  <option>Choose Department</option>
                                  <option>Software Design</option>
                                  <option>Development cycle</option>
                                  <option>Software Development</option>
                                  <option>Maintenance</option>
                                  <option>Process Query</option>
                                  <option>Cost and Duration</option>
                                  <option>Modal Delivery</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <select class="form-control" id="exampleFormControlSelect2">
                                  <option>Select Doctors</option>
                                  <option>Software Design</option>
                                  <option>Development cycle</option>
                                  <option>Software Development</option>
                                  <option>Maintenance</option>
                                  <option>Process Query</option>
                                  <option>Cost and Duration</option>
                                  <option>Modal Delivery</option>
                                </select>
                            </div>
                        </div>

                         <div class="col-lg-6">
                            <div class="form-group">
                                <input name="date" id="date" type="text" class="form-control" placeholder="dd/mm/yyyy">
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="time" id="time" type="text" class="form-control" placeholder="Time">
                            </div>
                        </div>
                         <div class="col-lg-6">
                            <div class="form-group">
                                <input name="name" id="name" type="text" class="form-control" placeholder="Full Name">
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <input name="phone" id="phone" type="Number" class="form-control" placeholder="Phone Number">
                            </div>
                        </div>
                    </div>
                    <div class="form-group-2 mb-4">
                        <textarea name="message" id="message" class="form-control" rows="6" placeholder="Your Message"></textarea>
                    </div>

                    <a class="btn btn-main btn-round-full" href="appoinment.html" >Make Appoinment <i class="icofont-simple-right ml-2  "></i></a>
                </form> -->
				<!-- new form -->
				 <div class="formbold-main-wrapper">
  <div class="formbold-form-wrapper">
    <form action="https://formbold.com/s/FORM_ID" method="POST">
      <div class="formbold-mb-5">
        <label for="name" class="formbold-form-label"> Full Name </label>
        <input
          type="text"
          name="name"
          id="name"
          placeholder="Full Name"
          class="formbold-form-input"
        />
      </div>
      <div class="formbold-mb-5">
        <label for="phone" class="formbold-form-label"> Phone Number </label>
        <input
          type="text"
          name="phone"
          id="phone"
          placeholder="Enter your phone number"
          class="formbold-form-input"
        />
      </div>
      <div class="formbold-mb-5">
        <label for="email" class="formbold-form-label"> Email Address </label>
        <!-- <input type="email"
          name="email"
          id="email"
          placeholder="Enter your email"
          class="formbold-form-input"
        /> -->
		      <div>
                <div class="form-group">
                                <select class="form-control" id="exampleFormControlSelect2">
                                  <option>Preferred Service / Department</option>
                                  <option>Consultations (General, Paediatric, Gynaecology)</option>
                                  <option>Laboratory</option>
                                  <option>Pharmacy</option>
                                  <option>Ultrasound</option>
                                  <option>Family Planning</option>
                                  <option>Maternity Care (Antenatal & Postnatal)</option>
                                  <option>Minor Surgery</option>
                                </select>
                            </div>
                        </div>
      </div>
      <div class="flex flex-wrap formbold--mx-3">
        <div class="w-full sm:w-half formbold-px-3">
          <div class="formbold-mb-5 w-full">
            <label for="date" class="formbold-form-label"> Date </label>
            <input
              type="date"
              name="date"
              id="date"
              class="formbold-form-input"
            />
          </div>
        </div>
        <div class="w-full sm:w-half formbold-px-3">
          <div class="formbold-mb-5">
            <label for="time" class="formbold-form-label"> Time </label>
            <input
              type="time"
              name="time"
              id="time"
              class="formbold-form-input"
            />
          </div>
        </div>
      </div>

      <!-- <div class="formbold-mb-5 formbold-pt-3">
        <label class="formbold-form-label formbold-form-label-2">
          Address Details
        </label>
        <div class="flex flex-wrap formbold--mx-3">
          <div class="w-full sm:w-half formbold-px-3">
            <div class="formbold-mb-5">
              <input
                type="text"
                name="area"
                id="area"
                placeholder="Enter area"
                class="formbold-form-input"
              />
            </div>
          </div>
          <div class="w-full sm:w-half formbold-px-3">
            <div class="formbold-mb-5">
              <input
                type="text"
                name="city"
                id="city"
                placeholder="Enter city"
                class="formbold-form-input"
              />
            </div>
          </div>
          <div class="w-full sm:w-half formbold-px-3">
            <div class="formbold-mb-5">
              <input
                type="text"
                name="state"
                id="state"
                placeholder="Enter state"
                class="formbold-form-input"
              />
            </div>
          </div>
          <div class="w-full sm:w-half formbold-px-3">
            <div class="formbold-mb-5">
              <input
                type="text"
                name="post-code"
                id="post-code"
                placeholder="Post Code"
                class="formbold-form-input"
              />
            </div>
          </div>
        </div>
      </div> -->

      <div>
        <button class="formbold-btn">Book Appointment</button>
      </div>
    </form>
  </div>
</div>
				 <!-- end new form -->
